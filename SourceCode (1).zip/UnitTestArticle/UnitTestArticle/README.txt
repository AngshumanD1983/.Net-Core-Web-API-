﻿To get this project running after compilation you might need to execute
the following command from the NuGet Package Manager Console

Update-Package Microsoft.CodeDom.Providers.DotNetCompilerPlatform -r