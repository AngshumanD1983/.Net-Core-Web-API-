﻿namespace UnitTestArticle.Services
{
    public class ReportingService : IReportingService
    {
        public void AccountIsOverdrawn(int id)
        {

        }
    }
}