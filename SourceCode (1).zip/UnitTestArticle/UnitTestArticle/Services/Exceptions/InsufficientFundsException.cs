﻿using System;

namespace UnitTestArticle.Services.Exceptions
{
    public class InsufficientFundsException : Exception
    {
    }
}