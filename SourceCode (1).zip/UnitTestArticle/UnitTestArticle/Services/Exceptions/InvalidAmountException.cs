﻿using System;

namespace UnitTestArticle.Services.Exceptions
{
    public class InvalidAmountException : Exception
    {
    }
}