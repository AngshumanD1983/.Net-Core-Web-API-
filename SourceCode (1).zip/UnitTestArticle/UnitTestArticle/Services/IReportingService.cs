﻿namespace UnitTestArticle.Services
{
    public interface IReportingService
    {
        void AccountIsOverdrawn(int id);
    }
}
